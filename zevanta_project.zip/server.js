
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
require('dotenv').config(); // Untuk menggunakan variabel environment dari .env

const app = express();
const port = process.env.PORT || 5000;

// Menggunakan CORS untuk mengizinkan akses dari frontend
app.use(cors());
app.use(express.json());

// Koneksi MySQL
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    process.exit(1);
  }
  console.log('Connected to MySQL');
});

// Route untuk mendapatkan semua prompt
app.get('/prompts', (req, res) => {
  db.query('SELECT * FROM prompts', (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.json(results);
    }
  });
});

// Route untuk menambah prompt
app.post('/prompts', (req, res) => {
  const { title, description, price, user_id } = req.body;
  db.query(
    'INSERT INTO prompts (title, description, price, user_id) VALUES (?, ?, ?, ?)',
    [title, description, price, user_id],
    (err, result) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.status(201).json({ id: result.insertId, title, description, price, user_id });
      }
    }
  );
});

// Menjalankan server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
    