
import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Dashboard() {
  const [prompts, setPrompts] = useState([]);

  useEffect(() => {
    fetchPrompts();
  }, []);

  const fetchPrompts = async () => {
    const response = await axios.get('http://localhost:5000/prompts');
    setPrompts(response.data);
  };

  return (
    <div>
      <h1>My Uploaded Prompts</h1>
      <ul>
        {prompts.map((prompt) => (
          <li key={prompt.id}>
            <h2>{prompt.title}</h2>
            <p>{prompt.description}</p>
            <p>{prompt.price}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
    