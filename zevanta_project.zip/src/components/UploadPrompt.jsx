
import React, { useState } from 'react';
import axios from 'axios';

export default function UploadPrompt() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/prompts', {
        title,
        description,
        price,
        user_id: 'user123',
      });
      alert('Prompt uploaded successfully!');
    } catch (error) {
      alert('Error uploading prompt');
    }
  };

  return (
    <div>
      <h1>Upload Prompt</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <input
          type="number"
          placeholder="Price (USD)"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
    